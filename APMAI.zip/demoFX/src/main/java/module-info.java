module com.example.demofx {
    requires javafx.controls;
    requires javafx.fxml;
        requires javafx.web;
            requires com.dlsc.formsfx;
            requires net.synedra.validatorfx;
            requires org.kordamp.ikonli.javafx;
            requires com.almasb.fxgl.all;
    requires java.desktop;

    opens com.example.demofx to javafx.fxml;
    exports com.example.demofx;
}