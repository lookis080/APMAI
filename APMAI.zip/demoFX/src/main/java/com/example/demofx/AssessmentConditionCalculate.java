package com.example.demofx;

import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AssessmentConditionCalculate {
    private static List<Button> dimensionMatrix = new ArrayList<Button>();
    private static List<Label> labelName=new ArrayList<Label>();
    private static List<Label> labelNameForWeight=new ArrayList<Label>();
    private static List<Label> labelNameClone=new ArrayList<Label>();
    public TextField textFieldCalculateArray[][];
    public static List<BlockHierarchy> blocksHierarchy = new ArrayList<BlockHierarchy>();
    public boolean flag=true;
    public static double IO=0.0;
    public static List<Double> vectorWeight;
    public static int indexActiveTab;
    public static double[] intermediateConditionArray;
    static double Ob=0;
    Stage stage2 = new Stage();
    int size;
    static double [] arrayCondition;
    static List<String> conditionList;

    @FXML
    Button importanseButtonCalculate;
    @FXML
    GridPane gridResult;
    @FXML
    AnchorPane secondAnchorPane;
    @FXML
    GridPane matrixGridPane = new GridPane();
    @FXML
    Button buttonExit;

    public double calculateMethod(List<BlockHierarchy> blocksHierarchy, double [] arrayCondition,
                                  List<String> conditionList, List<Double> vectorWeight) throws IOException {
        this.blocksHierarchy = blocksHierarchy;
        this.arrayCondition = arrayCondition;
        this.conditionList = conditionList;
        this.vectorWeight=vectorWeight;
        int bufSize=0;
        for (BlockHierarchy blockHierarchy : blocksHierarchy) {
            if (blockHierarchy.getStyle() == "-fx-background-color: red;" && indexActiveTab==blockHierarchy.ID_PANE) {
                bufSize++;

            }
        }
        FXMLLoader loaderCalculate = new FXMLLoader(getClass().getResource("assessment-condition-calculate-page.fxml"));
        AnchorPane rootCalculate = loaderCalculate.load();
        stage2.setTitle("АПМАИ:Расчет важности");
        stage2.setResizable(false);
        stage2.getIcons().add(new Image(getClass().getResource("LOGO.png").toExternalForm()));
        Scene sceneCalculate = new Scene(rootCalculate, 1030, 635);
        sceneCalculate.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        stage2.setScene(sceneCalculate);
        stage2.showAndWait();
        return Ob;
    }


    @FXML
    public void initialize() throws IOException {
        size = 0;
        secondAnchorPane.viewOrderProperty().set(1);
        stage2.setOnCloseRequest(exit);
        paintMethod();
        importanseButtonCalculate.setOnMouseClicked(calculateClick);
        buttonExit.setOnMouseClicked(exitClick);
        size = 0;
        gridResult.getChildren().remove(labelName);
        gridResult.getChildren().remove(labelNameClone);
    }
    EventHandler<WindowEvent> exit = new EventHandler<WindowEvent>() {
        @Override
        public void handle(WindowEvent windowEvent) {
            matrixGridPane.getChildren().clear();
        }
    };
    EventHandler<MouseEvent> calculateClick = new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent mouseEvent) {
            gridResult.getChildren().clear();
            Ob = 0;
            int MatrixInt[][] = new int[dimensionMatrix.size()][arrayCondition.length];
            boolean flagTry = true;
            for (int i = 0; i < dimensionMatrix.size(); i++) {
                for (int j = 0; j < arrayCondition.length; j++) {
                    MatrixInt[i][j] = Integer.parseInt(textFieldCalculateArray[i][j].getText());
                }
            }

            double sumLine = 0;
            System.out.println("dimension matrix" + dimensionMatrix.size());
            intermediateConditionArray=new double[arrayCondition.length];
            for (int i = 0; i<arrayCondition.length; i++){
                for (int j = 0; j<dimensionMatrix.size(); j++){
                    sumLine+=MatrixInt[j][i]*vectorWeight.get(j);
                }
                intermediateConditionArray[i]=sumLine;
                System.out.println("intermediateConditionArray " + intermediateConditionArray[i]);
                sumLine=0;
            }
            for (int i=0; i<arrayCondition.length; i++){
                Ob+=intermediateConditionArray[i]*arrayCondition[i];
                System.out.println("arrayCondition " + arrayCondition[i]);
                System.out.println(Ob);
            }
            System.out.println(Ob);
            Label label = new Label("Обобщение:");
            label.getStyleClass().add("text-gridpane");
            gridResult.add(label, 0, 0);
            label = new Label(Double.toString(Ob));
            label.getStyleClass().add("text-gridpane");
            gridResult.add(label, 1,0);

        }
    };
    public void paintMethod(){
        if (labelName.size()!=0){
            labelName.removeAll(labelName);
            labelNameClone.removeAll(labelNameClone);
            dimensionMatrix.removeAll(dimensionMatrix);
            labelNameForWeight.removeAll(labelNameForWeight);
        }
        for (BlockHierarchy blockHierarchy : this.blocksHierarchy) {

            if (blockHierarchy.getStyle() == "-fx-background-color: red;" && blockHierarchy.ID_PANE==this.indexActiveTab) {
                size++;
                dimensionMatrix.add(blockHierarchy);
                labelName.add(new Label(blockHierarchy.getText()));
            }
        }
        for (String str : conditionList){
            labelNameClone.add(new Label(str));
        }
        for (int i = 0; i<labelName.size(); i++){
            labelName.get(i).getStyleClass().add("text-gridpane");
        }
        for (int i = 0; i<labelNameClone.size(); i++) {
            labelNameClone.get(i).getStyleClass().add("text-gridpane");
        }
        textFieldCalculateArray = new TextField[dimensionMatrix.size()][arrayCondition.length];
        for (int i = 0; i < dimensionMatrix.size() + 1; i++) {
            for (int j = 0; j < arrayCondition.length + 1; j++) {

                if (i == 0 & j == 0) continue;
                if (i == 0) {
                    labelNameClone.get(j - 1).setStyle("-fx-padding: 0 5 0 5;");
                    matrixGridPane.add(labelNameClone.get(j - 1), i, j);
                } else if (j == 0) {
                    labelName.get(i - 1).setStyle("-fx-padding: 0 5 0 5;");
                    matrixGridPane.add(labelName.get(i - 1), i, j);
                } else {
                    textFieldCalculateArray[i - 1][j - 1] = new TextField();
                    matrixGridPane.add(textFieldCalculateArray[i - 1][j - 1], i, j);
                }
            }
        }
    }
    EventHandler<MouseEvent> exitClick = new EventHandler<MouseEvent>() {
        @Override
        public void handle(MouseEvent mouseEvent) {
            matrixGridPane.getChildren().clear();
            Stage stage = (Stage) buttonExit.getScene().getWindow();
            stage.close();
        }
    };
}
